import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-single-employee',
  templateUrl: './single-employee.component.html',
  styleUrls: ['./single-employee.component.scss']
})
export class SingleEmployeeComponent implements OnInit {

  constructor () { }

  ngOnInit(): void {
  }

}
