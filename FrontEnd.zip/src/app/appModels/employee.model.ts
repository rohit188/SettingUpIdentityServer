export interface Employee {
    _id : string;
    name: string;
    position: string;
    dept:string
}