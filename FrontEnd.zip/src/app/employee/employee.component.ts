import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.scss']
})

export class EmployeeComponent implements OnInit {
  empForm : FormGroup;
  showModal:boolean = false;
  editMode:boolean = false;

  constructor(
    private fb: FormBuilder
    ) { }

  ngOnInit(): void {
    this.empForm = this.fb.group({
      _id: [''],
      name: ['Ex. Alex Johnson', Validators.required],
      position: ['Ex. Full Stack Developer', Validators.required],
      dept: ['Development']
    })
  }

  onEmpSubmit(){
    if(this.empForm.valid){
      console.log(this.empForm.value);
      this.onReset();
      this.onCloseModal();

    }else{
      let key = Object.keys(this.empForm.controls);
      key.filter(data =>{
        let control = this.empForm.controls[data];
        if(control.errors !=null){
          control.markAsTouched();
        }
      })
    }
  }

  onEditEmployee(){
    this.editMode = true;
    this.showModal = true;;
  }

  onDeleteEmployee(id){
    if(confirm('Do you want to delete this employee?')){
      
    }
  }

  onAddEmployee(){
    this.showModal = true;
  }

  onCloseModal(){
    this.showModal = false;
    this.onReset();
    this.editMode = false;
  }

  onReset(){
    this.empForm.reset({
      name: 'Ex. Alex Johnson',
      position: 'Ex. Full Stack Developer',
      dept: 'Development'
    });
  }

}
